<?php
    $conn = mysqli_connect('localhost', 'root', 'rootroot', 'concesionario') 
    or die("Fallo accediendo:" . mysqli_connect_error());